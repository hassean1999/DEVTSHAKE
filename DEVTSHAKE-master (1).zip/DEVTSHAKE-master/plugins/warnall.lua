--[[ 
    _____    _        _    _    _____    Dev @lIMyIl 
   |_   _|__| |__    / \  | | _| ____|   Dev @li_XxX_il
     | |/ __| '_ \  / _ \ | |/ /  _|     Dev @h_k_a
     | |\__ \ | | |/ ___ \|   <| |___    Dev @Aram_omar22
     |_||___/_| |_/_/   \_\_|\_\_____|   Dev @IXX_I_XXI
--]]
local function pre_process(msg) 
local hka1 = 'hsaif:'..msg.to.id      --@h_k_a
local hka2 = 'hmooy:'..msg.to.id
local hka4 = 'hmoha:'..msg.to.id    --@h_k_a
local hka5 = 'hhait:'..msg.to.id 
local hka3 = 'hkab:'..msg.to.id  --@h_k_a
local hka6 = 'hemad:'..msg.to.id
local hka7 = 'htshk:'..msg.to.id
local h_k_a8 = 'hnon:'..msg.to.id     --@h_k_a
local h_k_a9 = 'h_k:' ..msg.to.id
local h_k_a10 = 'h_a:'..msg.to.id
local h_k_a11 = 'haaah:'..msg.to.id
local h_k_a14 = 'hhaa:'..msg.to.id
local ha = msg.text:match("/")
local hhaka = msg.text:match("😄😃😀😊☺️😉😍😘😚😗😙😜😝😛😳😁😔😌😒😞😣😢😂😭😪😥😰😅😓😩😫😨😱😠😡😤😖😆😋😷😎😴😵😲😟😦😧😈👿😮😬😐😕😯😶😇😏😑👲👳👮👷💂👶👦👧👨👩👴👵👱👼👸😺😸😻😽😼🙀😿😹😾👹👺🙈🙉🙊💀👽💩🔥✨🌟💫💥💢💦💧💤💨👂👀👃👅👄👍👎👌👊✊✌👋✋👐👆👇👉👈🙌🙏☝️👏💪🚶🏃💃👫👪👬👭💏💑👯🙆🙅💁🙋💆💇💅👰🙎🙍🙇🎩👑👒👟👞👡👠👢👕👔👚👗🎽👖👘👙💼👜👝👛👓🎀🌂💄💛💙💜💚❤️💔💗💓💕💖💞💘💌💋💍💎👤👥💬👣💭🐶🐺🐱🐭🐹🐰🐸🐯🐨🐻🐷🐽🐮🐗🐵🐒🐴🐑🐘🐼🐧🐦🐤🐥🐣🐔🐍🐢🐛🐝🐜🐞🐌🐙🐚🐠🐟🐬🐳🐋🐄🐏🐀🐃🐅🐇🐉🐎🐐🐓🐕🐖🐁🐂🐲🐡🐊🐫🐪🐆🐈🐩🐾💐🌸🌷🍀🌹🌻🌺🍁🍃🍂🌿🌾🍄🌵🌴🌲🌳🌰🌱🌼🌐🌞🌝🌚🌑🌒🌓🌔🌕🌖🌗🌘🌜🌛🌙🌍🌎🌏🌋🌌🌠⭐️☀️⛅️☁️⚡️☔️❄️⛄️🌀🌁🌈🌊🎍💝🎎🎒🎓🎏🎆🎇🎐🎑🎃👻🎅🎄🎁🎋🎉🎊🎈🎌🔮🎥📷📹📼💿📀💽💾💻📱☎️📞📟📠📡📺📻🔊🔉🔈🔇🔔🔕📢📣⏳⌛️⏰⌚️🔓🔒🔏🔐🔑🔎💡🔦🔆🔅🔌🔋🔍🛁🛀🚿🚽🔧🔩🔨🚪🚬💣🔫🔪💊💉💰💴💵💷💶💳💸📲📧📥📤✉️📩📨📯📫📪📬📭📮📦📝📄📃📑📊📈📉📜📋📅📆📇📁📂✂️📌📎✒️✏️📏📐📕📗📘📙📓📔📒📚📖🔖📛🔬🔭📰🎨🎬🎤🎧🎼🎵🎶🎹🎻🎺🎷🎸👾🎮🃏🎴🀄️🎲🎯🏈🏀⚽️⚾️🎾🎱🏉🎳⛳️🚵🚴🏁🏇🏆🎿🏂🏊🏄🎣☕️🍵🍶🍼🍺🍻🍸🍹🍷🍴🍕🍔🍟🍗🍖🍝🍛🍤🍱🍣🍥🍙🍘🍚🍜🍲🍢🍡🍳🍞🍩🍮🍦🍨🍧🎂🍰🍪🍫🍬🍭🍯🍎🍏🍊🍋🍒🍇🍉🍓🍑🍈🍌🍐🍍🍠🍆🍅🌽🏠🏡🏫🏢🏣🏥🏦🏪🏩🏨💒⛪️🏬🏤🌇🌆🏯🏰⛺️🏭🗼🗾🗻🌄🌅🌃🗽🌉🎠🎡⛲️🎢🚢⛵️🚤🚣⚓️🚀✈️💺🚁🚂🚊🚉🚞🚆🚄🚅🚈🚇🚝🚋🚃🚎🚌🚍🚙🚘🚗🚕🚖🚛🚚🚨🚓🚔🚒🚑🚐🚲🚡🚟🚠🚜💈🚏🎫🚦🚥⚠️🚧🔰⛽️🏮🎰♨️🗿🎪🎭📍🚩🇯🇵🇰🇷🇩🇪🇨🇳🇺🇸🇫🇷🇪🇸🇮🇹🇷🇺🇬🇧1⃣2⃣3⃣4⃣5⃣6⃣7⃣8⃣9⃣0⃣🔟🔢#⃣🔣⬆️⬇️⬅️➡️🔠🔡🔤↗️↖️↘️↙️↔️↕️🔄◀️▶️🔼🔽↩️↪️ℹ️⏪⏩⏫⏬⤵️⤴️🆗🔀🔁🔂🆕🆙🆒🆓🆖📶🎦🈁🈯️🈳🈵🈴🈲🉐🈹🈺🈶🈚️🚻🚹🚺🚼🚾🚰🚮🅿️♿️🚭🈷🈸🈂Ⓜ️🛂🛄🛅🛃🉑㊙️㊗️🆑🆘🆔🚫🔞📵🚯🚱🚳🚷🚸⛔️✳️❇️❎✅✴️💟🆚📳📴🅰🅱🆎🅾💠➿♻️♈️♉️♊️♋️♌️♍️♎️♏️♐️♑️♒️♓️⛎🔯🏧💹💲💱©®™❌‼️⁉️❗️❓❕❔⭕️🔝🔚🔙🔛🔜🔃🕛🕧🕐🕜🕑🕝🕒🕞🕓🕟🕔🕠🕕🕖🕗🕘🕙🕚🕡🕢🕣🕤🕥🕦✖️➕➖➗♠️♥️♣️♦️💮💯✔️☑️🔘🔗➰〰〽️🔱◼️◻️◾️◽️▪️▫️🔺🔲🔳⚫️⚪️🔴🔵🔻⬜️⬛️🔶🔷🔸🔹😄😃😀😊☺️😉😍😘😚😗😙😜😝😛😳😁😔😌😒😞😣😢😂😭😪😥😰😅😓😩😫😨😱😠😡😤😖😆😋😷😎😴😵😲😟😦😧😈👿😮😬😐😕😯😶😇😏😑👲👳👮👷💂👶👦👧👨👩👴👵👱👼👸😺😸😻😽😼🙀😿😹😾👹👺🙈🙉🙊💀👽💩🔥✨🌟💫💥💢💦💧💤💨👂👀👃👅👄👍👎👌👊✊✌👋✋👐👆👇👉👈🙌🙏☝️👏💪🚶🏃💃😄😃😀😊☺️😉😍😘😚😗😙😜😝😛😳😁😔😌😒😞😣😢😂😭😪😥😰😅😓😩😫😨😱😠😡😤😖😆😋😷😎😴😵😲😟😦😧😈👿😮😬😐😕😯😶😇😏😑👲👳👮👷💂👶👦👧👨👩👴👵👱👼👸😺😸😻😽😼🙀😿😹😾👹👺🙈🙉🙊💀👽💩🔥✨🌟💫💥💢💦💧💤💨👂👀👃👅👄👍👎👌👊✊✌👋✋👐👆👇👉👈🙌🙏☝️👏💪🚶🏃💃👫👪👬👭💏💑👯🙆🙅💁🙋💆💇💅👰🙎🙍🙇🎩👑👒👟👞👡👠👢👕👔👚👗🎽👖👘👙💼👜👝👛👓🎀🌂💄💛💙💜💚❤️💔💗💓💕💖💞💘💌💋💍💎👤👥💬👣💭🐶🐺🐱🐭🐹🐰🐸🐯🐨🐻🐷🐽🐮🐗🐵🐒🐴🐑🐘🐼🐧🐦🐤🐥🐣🐔🐍🐢🐛🐝🐜🐞🐌🐙🐚🐠🐟🐬🐳🐋🐄🐏🐀🐃🐅🐇🐉🐎🐐🐓🐕🐖🐁🐂🐲🐡🐊🐫🐪🐆🐈🐩🐾💐🌸🌷🍀🌹🌻🌺🍁🍃🍂🌿🌾🍄🌵🌴🌲🌳🌰🌱🌼🌐🌞🌝🌚🌑🌒🌓🌔🌕🌖🌗🌘🌜🌛🌙🌍🌎🌏🌋🌌🌠⭐️☀️⛅️☁️⚡️☔️❄️⛄️🌀🌁🌈🌊🎍💝🎎🎒🎓🎏🎆🎇🎐🎑🎃👻🎅🎄🎁🎋🎉🎊🎈🎌🔮🎥📷📹📼💿📀💽💾💻📱☎️📞📟📠📡📺📻🔊🔉🔈🔇🔔🔕📢📣⏳⌛️⏰⌚️🔓🔒🔏🔐🔑🔎💡🔦🔆🔅🔌🔋🔍🛁🛀🚿🚽🔧🔩🔨🚪🚬💣🔫🔪💊💉💰💴💵💷💶💳💸📲📧📥📤✉️📩📨📯📫📪📬📭📮📦📝📄📃📑📊📈📉📜📋📅📆📇📁📂✂️📌📎✒️✏️📏📐📕📗📘📙📓📔📒📚📖🔖📛🔬🔭📰🎨🎬🎤🎧🎼🎵🎶🎹🎻🎺🎷🎸👾🎮🃏🎴🀄️🎲🎯🏈🏀⚽️⚾️🎾🎱🏉🎳⛳️🚵🚴🏁🏇🏆🎿🏂🏊🏄🎣☕️🍵🍶🍼🍺🍻🍸🍹🍷🍴🍕🍔🍟🍗🍖🍝🍛🍤🍱🍣🍥🍙🍘🍚🍜🍲🍢🍡🍳🍞🍩🍮🍦🍨🍧🎂🍰🍪🍫🍬🍭🍯🍎🍏🍊🍋🍒🍇🍉🍓🍑🍈🍌🍐🍍🍠🍆🍅🌽🏠🏡🏫🏢🏣🏥🏦🏪🏩🏨💒⛪️🏬🏤🌇🌆🏯🏰⛺️🏭🗼🗾🗻🌄🌅🌃🗽🌉🎠🎡⛲️🎢🚢⛵️🚤🚣⚓️🚀✈️💺🚁🚂🚊🚉🚞🚆🚄🚅🚈🚇🚝🚋🚃🚎🚌🚍🚙🚘🚗🚕🚖🚛🚚🚨🚓🚔🚒🚑🚐🚲🚡🚟🚠🚜💈🚏🎫🚦🚥⚠️🚧🔰⛽️🏮🎰♨️🗿🎪🎭📍🚩🇯🇵🇰🇷🇩🇪🇨🇳🇺🇸🇫🇷🇪🇸🇮🇹🇷🇺🇬🇧1⃣2⃣3⃣4⃣5⃣6⃣7⃣8⃣9⃣0⃣🔟🔢#⃣🔣⬆️⬇️⬅️➡️🔠🔡🔤↗️↖️↘️↙️↔️↕️🔄◀️▶️🔼🔽↩️↪️ℹ️⏪⏩⏫⏬⤵️⤴️🆗🔀🔁🔂🆕🆙🆒🆓🆖📶🎦🈁🈯️🈳🈵🈴🈲🉐🈹🈺🈶🈚️🚻🚹🚺🚼🚾🚰🚮🅿️♿️🚭🈷🈸🈂Ⓜ️🛂🛄🛅🛃🉑㊙️㊗️🆑🆘🆔🚫🔞📵🚯🚱🚳🚷🚸⛔️✳️❇️❎✅✴️💟🆚📳📴🅰🅱🆎🅾💠➿♻️♈️♉️♊️♋️♌️♍️♎️♏️♐️♑️♒️♓️⛎🔯🏧💹💲💱©®™❌‼️⁉️❗️❓❕❔⭕️🔝🔚🔙🔛🔜🔃🕛🕧🕐🕜🕑🕝🕒🕞🕓🕟🕔🕠🕕🕖🕗🕘🕙🕚🕡🕢🕣🕤🕥🕦✖️➕➖➗♠️♥️♣️♦️💮💯✔️☑️🔘🔗➰〰〽️🔱◼️◻️◾️◽️▪️▫️🔺🔲🔳⚫️⚪️🔴🔵🔻⬜️⬛️🔶🔷🔸🔹😄😃😀😊☺️😉😍😘😚😗😙😜😝😛😳😁😔😌😒😞😣😢😂😭😪😥😰😅😓😩😫😨😱😠😡😤😖😆😋😷😎😴😵😲😟😦😧😈👿😮😬😐😕😯😶😇😏😑👲👳👮👷💂👶👦👧👨👩👴👵👱👼👸😺😸😻😽😼🙀😿😹😾👹👺🙈🙉🙊💀👽💩🔥✨🌟💫💥💢💦💧💤💨👂👀👃👅👄👍👎👌👊✊✌👋✋👐👆👇👉👈🙌🙏☝️👏💪🚶🏃💃")
local hk = msg.text:match("@") 
local hb = msg.text:match("#")
local hka = msg.text:match("[Hh][Tt][Tt][Pp][Ss]://") or msg.text:match("[Tt][Ee][Ll][Ee][Gg][Rr][Aa][Mm]%.[Mm][Ee]/") or msg.text:match("[Tt][Ll][Gg][Rr][Mm]%.[Mm][Ee]/") or msg.text:match("[Tt][Ee][Ll][Ee][Gg][Rr][Aa][Mm]%.[Oo][Rr][Gg]") or msg.text:match("[Gg][Oo][Oo]%.[Gg][Li]/")  or msg.text:match("[Tt][Ee][Ll][Ee][Gg][Rr][Aa][Mm]%.[Mm][Ee]") or msg.text:match("(https://t.me/)") or msg.text:match("[Tt].[Mm][Ee]/")--@h_k_a
if redis:get(hka1) and not is_momod(msg) and hka then
delete_msg(msg.id, ok_cb, true)
send_large_msg(get_receiver(msg), '#تـنـبـيـه ⚠️\nمـمـنـوع ارسـال #الـروابـط 🔕 داخـــل الــمــجــمــوعــة 👥✔️\n#المعرف @'..msg.from.username or '')
elseif redis:get(hka7) and not is_momod(msg) and hk then
delete_msg(msg.id, ok_cb, true)
send_large_msg(get_receiver(msg), '#تـنـبـيـه ⚠️\nمـمـنـوع ارسـال #الـمـعـرفـات 🔕 داخـــل الــمــجــمــوعــة 👥✔️\n#المعرف @'..msg.from.username or '')
elseif redis:get(h_k_a10) and not is_momod(msg) and hb then
delete_msg(msg.id, ok_cb, true)
send_large_msg(get_receiver(msg), '#تـنـبـيـه ⚠️\nمـمـنـوع ارسـال #الـتـاكـات 🔕 داخـــل الــمــجــمــوعــة 👥✔️\n#المعرف @'..msg.from.username or '')
elseif redis:get(hka2) and not is_momod(msg) and msg.fwd_from then
delete_msg(msg.id, ok_cb, true)
send_large_msg(get_receiver(msg), '#تـنـبـيـه ⚠️\nمـمـنـوع عــمــل الـتـوجـيـه 🔕 داخـــل الــمــجــمــوعــة 👥✔️\n#المعرف @'..msg.from.username)
elseif redis:get(hka4) and not is_momod(msg) and msg.media and msg.media.type == 'photo' then
delete_msg(msg.id, ok_cb, true)
send_large_msg(get_receiver(msg), '#تـنـبـيـه ⚠️\nمـمـنـوع ارسـال #الـصـور 🔕 داخـــل الــمــجــمــوعــة 👥✔️\n#المعرف @'..msg.from.username or '')
elseif redis:get(hka5) and not is_momod(msg) and msg.media and msg.media.type == 'audio' then
delete_msg(msg.id, ok_cb, true)
send_large_msg(get_receiver(msg), '#تـنـبـيـه ⚠️\nمـمـنـوع ارسـال #الـصـوت 🔕 داخـــل الــمــجــمــوعــة 👥✔️\n#المعرف @'..msg.from.username or '')
elseif redis:get(hka3) and not is_momod(msg) and msg.media and msg.media.type == 'video' then
delete_msg(msg.id, ok_cb, true)
send_large_msg(get_receiver(msg), '#تـنـبـيـه ⚠️\nمـمـنـوع ارسـال #الفـيـديـو 🔕 داخـــل الــمــجــمــوعــة 👥✔️\n#المعرف @'..msg.from.username or '')
elseif redis:get(h_k_a14) and not is_momod(msg) and hhaka then
delete_msg(msg.id, ok_cb, true)
send_large_msg(get_receiver(msg), '#تـنـبـيـه ⚠️\nمـمـنـوع ارسـال #الـسـمـايـلات 🔕 داخـــل الــمــجــمــوعــة 👥✔️\n#المعرف @'..msg.from.username or '')
elseif redis:get(hka6) and not is_momod(msg) and msg.to.type == 'channel' then
delete_msg(msg.id, ok_cb, true)
send_large_msg(get_receiver(msg), '#تـنـبـيـه ⚠️\nمـمـنـوعـه الـدردشـه 🔕 داخـــل الــمــجــمــوعــة 👥✔️\n#المعرف @'..msg.from.username or '')
elseif redis:get(h_k_a8) and not is_momod(msg) and ha then
delete_msg(msg.id, ok_cb, true)
send_large_msg(get_receiver(msg), '#تـنـبـيـه ⚠️\nمـمـنـوع ارسـال #الشـارحـه 🔕 داخـــل الــمــجــمــوعــة 👥✔️\n#المعرف @'..msg.from.username or '')
elseif redis:get(h_k_a9) and not is_momod(msg) and msg.text == '[unsupported]' then
delete_msg(msg.id, ok_cb, true)
send_large_msg(get_receiver(msg), '#تـنـبـيـه ⚠️\nمـمـنـوع ارسـال #الـانـلاينـ 🔕 داخـــل الــمــجــمــوعــة 👥✔️\n#المعرف @'..msg.from.username or '')
elseif redis:get(h_k_a11) and not is_momod(msg) and msg.media then
delete_msg(msg.id, ok_cb, true)
send_large_msg(get_receiver(msg), '#تـنـبـيـه ⚠️\nمـمـنـوع ارسـال #الـمـيـديـا 🔕 داخـــل الــمــجــمــوعــة 👥✔️\n#المعرف @'..msg.from.username or '')
return "done"
   end --@h_k_a
   return msg
 end
 
 
local function h_k_a(msg, matches) 
    chat_id =  msg.to.id 
if is_momod(msg) and matches[1]== 'قفل' and matches[2]== 'الروابط بالتحذير' then
   local hka1 = 'hsaif:'..msg.to.id  
    redis:set(hka1, true)
return '#تـمـ☑️ قـفـلـ #الـروابـط بـالـتـحـذيـر 📛 فـي | '..msg.to.title..' |\n#بواسطه |❗️| (@'..(msg.from.username or 'لا يوجد')..')\n'
 elseif is_momod(msg) and matches[1]== 'فتح' and matches[2]== 'الروابط بالتحذير' then
   local hka1 = 'hsaif:'..msg.to.id  
    redis:del(hka1)
return '#تـمـ⚠️ فـتـحـ #الـروابـط بـالـتـحـذيـر 📛 فـي | '..msg.to.title..' |\n#بواسطه |❗️| (@'..(msg.from.username or 'لا يوجد')..')\n'       
        --@h_k_a
end

if is_momod(msg) and matches[1]== 'قفل' and matches[2]== 'التوجيه بالتحذير' then
   local hka2 = 'hmooy:'..msg.to.id  --@h_k_a
    redis:set(hka2, true)
return '#تـمـ☑️ قـفـلـ #الـتـوجـيـه بـالـتـحـذيـر 📛 فـي | '..msg.to.title..' |\n#بواسطه |❗️| (@'..(msg.from.username or 'لا يوجد')..')\n'
 elseif is_momod(msg) and matches[1]== 'فتح' and matches[2]== 'التوجيه بالتحذير' then
   local hka2 = 'hmooy:'..msg.to.id 
    redis:del(hka2)
return '#تـمـ⚠️ فـتـحـ #الـتـوجـيـه بـالـتـحـذيـر 📛 فـي | '..msg.to.title..' |\n#بواسطه |❗️| (@'..(msg.from.username or 'لا يوجد')..')\n'       
       
end
if is_momod(msg) and matches[1]== 'قفل' and matches[2]== 'الصور بالتحذير' then
  local hka4 = 'hmoha:'..msg.to.id 
    redis:set(hka4, true)
return '#تـمـ☑️ قـفـلـ #الـصـور بـالـتـحـذيـر 📛 فـي | '..msg.to.title..' |\n#بواسطه |❗️| (@'..(msg.from.username or 'لا يوجد')..')\n'
elseif is_momod(msg) and matches[1]== 'فتح' and matches[2]== 'الصور بالتحذير' then
    local hka4 = 'hmoha:'..msg.to.id 
    redis:del(hka4)
return '#تـمـ⚠️ فـتـحـ #الـصـور بـالـتـحـذيـر 📛 فـي | '..msg.to.title..' |\n#بواسطه |❗️| (@'..(msg.from.username or 'لا يوجد')..')\n'       
end
if is_momod(msg) and matches[1]== 'قفل' and matches[2]== 'الصوت بالتحذير' then
   local hka5 =  'hhait:'..msg.to.id 
    redis:set(hka5, true)
return '#تـمـ☑️ قـفـلـ #الـصـوت بـالـتـحـذيـر 📛 فـي | '..msg.to.title..' |\n#بواسطه |❗️| (@'..(msg.from.username or 'لا يوجد')..')\n'
 elseif is_momod(msg) and matches[1]== 'فتح' and matches[2]== 'الصوت بالتحذير' then
  local hka5 =  'hhait:'..msg.to.id 
    redis:del(hka5) --@h_k_a
return '#تـمـ⚠️ فـتـحـ #الـصـوت بـالـتـحـذيـر 📛 فـي | '..msg.to.title..' |\n#بواسطه |❗️| (@'..(msg.from.username or 'لا يوجد')..')\n'       
    
end
if is_momod(msg) and matches[1]== 'قفل' and matches[2]== 'الفيديو بالتحذير' then
  local hka3 = 'hkab:'..msg.to.id
    redis:set(hka3, true)
return '#تـمـ☑️ قـفـلـ #الفـيـديـو بـالـتـحـذيـر 📛 فـي | '..msg.to.title..' |\n#بواسطه |❗️| (@'..(msg.from.username or 'لا يوجد')..')\n'
 elseif is_momod(msg) and matches[1]== 'فتح' and matches[2]== 'الفيديو بالتحذير'  then
 local hka3 = 'hkab:'..msg.to.id
    redis:del(hka3) --@h_k_a
return '#تـمـ⚠️ فـتـحـ #الفـيـديـو بـالـتـحـذيـر 📛 فـي | '..msg.to.title..' |\n#بواسطه |❗️| (@'..(msg.from.username or 'لا يوجد')..')\n'       
end
if is_momod(msg) and matches[1]== 'قفل' and matches[2]== 'الدردشه بالتحذير'  then
 local hka6 = 'hemad:'..msg.to.id
    redis:set(hka6, true)
return '#تـمـ☑️ قـفـلـ #الـدردشـه بـالـتـحـذيـر 📛 فـي | '..msg.to.title..' |\n#بواسطه |❗️| (@'..(msg.from.username or 'لا يوجد')..')\n'
 elseif is_momod(msg) and matches[1]== 'فتح' and matches[2]== 'الدردشه بالتحذير'  then
 local hka6 = 'hemad:'..msg.to.id
    redis:del(hka6) --@h_k_a
return '#تـمـ⚠️ فـتـحـ #الـدردشـه بـالـتـحـذيـر 📛 فـي | '..msg.to.title..' |\n#بواسطه |❗️| (@'..(msg.from.username or 'لا يوجد')..')\n'       
    
end
if is_momod(msg) and matches[1]== 'قفل' and matches[2]== 'المعرف بالتحذير'  then
 local hka7 = 'htshk:'..msg.to.id
    redis:set(hka7, true)
return '#تـمـ☑️ قـفـلـ #الـمـعـرف بـالـتـحـذيـر 📛 فـي | '..msg.to.title..' |\n#بواسطه |❗️| (@'..(msg.from.username or 'لا يوجد')..')\n'
 elseif is_momod(msg) and matches[1]== 'فتح' and matches[2]== 'المعرف بالتحذير'  then
local hka7 = 'htshk:'..msg.to.id
    redis:del(hka7) --@h_k_a
return '#تـمـ⚠️ فـتـحـ #الـمـعـرف بـالـتـحـذيـر 📛 فـي | '..msg.to.title..' |\n#بواسطه |❗️| (@'..(msg.from.username or 'لا يوجد')..')\n'       
    
end

if is_momod(msg) and matches[1]== 'قفل' and matches[2]== 'الشارحه بالتحذير'  then
  local h_k_a8 = 'hnon:'..msg.to.id
    redis:set(h_k_a8, true)
return '#تـمـ☑️ قـفـلـ #الـشـارحـه بـالـتـحـذيـر 📛 فـي | '..msg.to.title..' |\n#بواسطه |❗️| (@'..(msg.from.username or 'لا يوجد')..')\n'
 elseif is_momod(msg) and matches[1]== 'فتح' and matches[2]== 'الشارحه بالتحذير'  then
   local h_k_a8 = 'hnon:'..msg.to.id
    redis:del(h_k_a8)
return '#تـمـ⚠️ فـتـحـ #الـشـارحـه بـالـتـحـذيـر 📛 فـي | '..msg.to.title..' |\n#بواسطه |❗️| (@'..(msg.from.username or 'لا يوجد')..')\n'       
       
end
if is_momod(msg) and matches[1]== 'قفل' and matches[2]== 'الانلاين بالتحذير' then
  local h_k_a9 = 'h_k:' ..msg.to.id
    redis:set(h_k_a9, true)
return '#تـمـ☑️ قـفـلـ #الـانـلايـنـ بـالـتـحـذيـر 📛 فـي | '..msg.to.title..' |\n#بواسطه |❗️| (@'..(msg.from.username or 'لا يوجد')..')\n'
 elseif is_momod(msg) and matches[1]== 'فتح' and matches[2]== 'الانلاين بالتحذير' then
  local h_k_a9 = 'h_k:' ..msg.to.id
    redis:del(h_k_a9)  --@h_k_a
return '#تـمـ⚠️ فـتـحـ #الـانـلايـنـ بـالـتـحـذيـر 📛 فـي | '..msg.to.title..' |\n#بواسطه |❗️| (@'..(msg.from.username or 'لا يوجد')..')\n'       
       
end
if is_momod(msg) and matches[1]== 'قفل' and matches[2]== 'التاك بالتحذير' then
  local h_k_a10 = 'h_a:'..msg.to.id
    redis:set(h_k_a10, true)
return '#تـمـ☑️ قـفـلـ #الـتـاكـ بـالـتـحـذيـر 📛 فـي | '..msg.to.title..' |\n#بواسطه |❗️| (@'..(msg.from.username or 'لا يوجد')..')\n'
 elseif is_momod(msg) and matches[1]== 'فتح' and matches[2]== 'التاك بالتحذير' then
 local h_k_a10 = 'h_a:'..msg.to.id
    redis:del(h_k_a10)  --@h_k_a
return '#تـمـ⚠️ فـتـحـ #الـتـاكـ بـالـتـحـذيـر 📛 فـي | '..msg.to.title..' |\n#بواسطه |❗️| (@'..(msg.from.username or 'لا يوجد')..')\n'       
    
end
if is_momod(msg) and matches[1]== 'قفل' and matches[2]== 'السمايل بالتحذير'  then
 local  h_k_a14 = 'hhaa:'..msg.to.id
    redis:set(h_k_a14, true)
return '#تـمـ☑️ قـفـلـ #الـسـمـايـل بـالـتـحـذيـر 📛 فـي | '..msg.to.title..' |\n#بواسطه |❗️| (@'..(msg.from.username or 'لا يوجد')..')\n'
 elseif is_momod(msg) and matches[1]== 'فتح' and matches[2]==  'السمايل بالتحذير'  then
 local  h_k_a14 = 'hhaa:'..msg.to.id
    redis:del(h_k_a14)  --@h_k_a
return '#تـمـ⚠️ فـتـحـ #الـسـمـايـل بـالـتـحـذيـر 📛 فـي | '..msg.to.title..' |\n#بواسطه |❗️| (@'..(msg.from.username or 'لا يوجد')..')\n'       
end
if is_momod(msg) and matches[1]== 'قفل' and matches[2]== 'الميديا بالتحذير'  then
 local  h_k_a11 = 'haaah:'..msg.to.id
    redis:set(h_k_a11, true)
return '#تـمـ☑️ قـفـلـ #الـمـيـديـا بـالـتـحـذيـر 📛 فـي | '..msg.to.title..' |\n#بواسطه |❗️| (@'..(msg.from.username or 'لا يوجد')..')\n'
 elseif is_momod(msg) and matches[1]== 'فتح' and matches[2]==  'الميديا بالتحذير'  then
 local  h_k_a11 = 'haaah:'..msg.to.id
    redis:del(h_k_a11)  --@h_k_a
return '#تـمـ⚠️ فـتـحـ #الـمـيـديـا بـالـتـحـذيـر 📛 فـي | '..msg.to.title..' |\n#بواسطه |❗️| (@'..(msg.from.username or 'لا يوجد')..')\n'       
end
----------الاعدادات-------------

if matches[1] == "اعدادات التحذير" and is_momod(msg) then
local hka1 = 'hsaif:'..msg.to.id      --@h_k_a
local hka2 = 'hmooy:'..msg.to.id
local hka4 = 'hmoha:'..msg.to.id    --@h_k_a
local hka5 = 'hhait:'..msg.to.id 
local hka3 = 'hkab:'..msg.to.id  --@h_k_a
local hka6 = 'hemad:'..msg.to.id
local hka7 = 'htshk:'..msg.to.id
local h_k_a8 = 'hnon:'..msg.to.id     --@h_k_a
local h_k_a9 = 'h_k:' ..msg.to.id
local h_k_a10 = 'h_a:'..msg.to.id
local h_k_a11 = 'haaah:'..msg.to.id
local  h_k_a14 = 'hhaa:'..msg.to.id
-- -- -- --
local settings_tshake = 'اعـداداتـ الـتـحـذيـر فـي\n'..msg.to.title..'\n'
.."|📡| #الـانـلـايـنـ | "..(redis:get(h_k_a9) or "false").."\n"
.."|🗼| #الـصـور | "..(redis:get(hka4) or "false").."\n"
.."|🎤| #الـصـوتـ | "..(redis:get(hka5) or "false").."\n\n"
.."|🎥| #الـفـيـديـو | "..(redis:get(hka3) or "false").."\n"
.."|↪️| #التوجيه | "..(redis:get(hka2) or "false").."\n"
.."|〰| #الـشـارحـه | "..(redis:get(h_k_a8) or "false").."\n"
.."|⚠️| #الـروابـط | "..(redis:get(hka1) or "false").."\n\n"
.."|🌀| #الـمعـرفـاتـ | "..(redis:get(hka7) or "false").."\n"
.."|#⃣| #الـتـاكـاتـ | "..(redis:get(h_k_a10) or "false").."\n"
.."|😴| #الـسـمـايـلـاتـ | "..(redis:get(h_k_a14) or "false").."\n"
.."|🎐| #الـمـيـديـا | "..(redis:get(h_k_a11) or "false").."\n"
return settings_tshake
end
end
return {
    patterns = {
        '^(اعدادات التحذير)$',
        '^(قفل) (الروابط بالتحذير)$',
        '^(فتح) (الروابط بالتحذير)$',
        '^(قفل) (التوجيه بالتحذير)$',
        '^(فتح) (التوجيه بالتحذير)$',
        '^(قفل) (الصور بالتحذير)$',
        '^(فتح) (الصور بالتحذير)$',
        '^(قفل) (الصوت بالتحذير)$',
        '^(فتح) (الصوت بالتحذير)$',
        '^(قفل) (الفيديو بالتحذير)$',
        '^(فتح) (الفيديو بالتحذير)$',
        '^(قفل) (الدردشه بالتحذير)$',
        '^(فتح) (الدردشه بالتحذير)$',
        '^(قفل) (المعرف بالتحذير)$',
        '^(فتح) (المعرف بالتحذير)$',
        '^(قفل) (الشارحه بالتحذير)$',
        '^(فتح) (الشارحه بالتحذير)$',
        '^(قفل) (الانلاين بالتحذير)$',
        '^(فتح) (الانلاين بالتحذير)$',
        '^(قفل) (التاك بالتحذير)$',
        '^(فتح) (التاك بالتحذير)$',
        '^(قفل) (السمايل بالتحذير)$',
        '^(فتح) (السمايل بالتحذير)$',
        '^(قفل) (الميديا بالتحذير)$',
        '^(فتح) (الميديا بالتحذير)$',
    },
    run = h_k_a,
    pre_process = pre_process
}

--  تم الكتابه بواسطه @h_k_a
--  لا تغيير الحقوق .. الملف خاص قناه تشاكي  
--[[ 
    _____    _        _    _    _____    Dev @lIMyIl 
   |_   _|__| |__    / \  | | _| ____|   Dev @li_XxX_il
     | |/ __| '_ \  / _ \ | |/ /  _|     Dev @h_k_a
     | |\__ \ | | |/ ___ \|   <| |___    Dev @Aram_omar22
     |_||___/_| |_/_/   \_\_|\_\_____|   Dev @IXX_I_XXI
--]]
